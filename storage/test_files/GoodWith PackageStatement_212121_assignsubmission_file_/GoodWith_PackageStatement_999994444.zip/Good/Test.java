import java.util.Scanner;

package test;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input;

		while (true) {
			System.out.print("Say something: ");
			input = sc.nextLine();
			if (input.equals("quit")) {
				break;
			} else {
				System.out.println("Your text: " + input);
			}
		}
	}
}
