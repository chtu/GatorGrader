
package test;
/**
 *
 * @author shado
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //The first one is converting 26 liters to gallons.
        double num1 = 26;
        double num2 = .26;
        double answer1 = num1 * num2;
        System.out.println("26 liters is equal to about " + answer1 + " gallons.");
        //This next one is to convert 3.58 liters to gallons.
        double num3 = 3.58;
        double num4 = .26;
        double answer2 = num3 * num4;
        System.out.println("3.58 liters is equal to about " + answer2 + " gallons.");
        //This next one converts 4.5 gallons to liters.
        double num5 = 4.5;
        double num6 = .26;
        double answer3 = num5 / num6;
        System.out.println("4.5 gallons is equal to about " + answer3 + " liters.");
        
        //The next ones will work with kilos and pounds
        //This first one converts 56 kilos to pounds.
        double num7 = 56;
        double num8 = 2.2;
        double answer4 = num7 * num8;
        System.out.println("56 kilos is equal to about " + answer4 + " pounds.");
        //This next one will convert 1.23 pounds to kilos.
        double num9 = 1.23;
        double num10 = 2.2;
        double answer5 = num9 / num10;
        System.out.println("1.23 pounds is equal to about " + answer5 + " kilos.");
        
    }
    
}
