import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double input;

		while (true) {
			System.out.print("Divide 100 by something: ");
			input = sc.nextDouble();
			double result = 100/input;
			System.out.println("Your answer: " + result + "\n");
		}
	}
}
